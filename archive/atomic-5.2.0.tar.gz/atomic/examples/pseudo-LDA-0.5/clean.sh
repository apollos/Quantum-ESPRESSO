rm -r -f results
rm -r -f *CRASH*
